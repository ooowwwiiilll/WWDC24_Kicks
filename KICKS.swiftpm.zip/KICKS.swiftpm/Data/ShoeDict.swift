import Foundation

let sportOptions = ["B", "H", "L"]
let basketball1 = ["1", "2", "3"]
let basketball2 = ["A", "P", "S"]

let a1 = UserDefaults.standard.string(forKey: "a1")
let a2 = UserDefaults.standard.string(forKey: "a2")
let a3 = UserDefaults.standard.string(forKey: "a3")

let shoe = ["B1A": "SB1", "B1P": "SB1", "B1S": "SB1",
            "B2A": "SB1", "B2P": "SB1", "B2S": "SB1",
            "B3A": "SB1", "B3P": "SB1", "B3S": "SB1",
            
            "H1A": "SB2", "H1P": "SB2", "H1S": "SB2",
            "H2A": "SB2", "H2P": "SB2", "H2S": "SB2",
            "H3A": "SB2", "H3P": "SB2", "H3S": "SB2",
            
            "L1A": "SB3", "L1P": "SB3", "L1S": "SB3",
            "L2A": "SB3", "L2P": "SB3", "L2S": "SB3",
            "L3A": "SB3", "L3P": "SB3", "L3S": "SB3",
]

func getShoeResult() -> String {
    if let a1 = UserDefaults.standard.string(forKey: "a1"), let a2 = UserDefaults.standard.string(forKey: "a2"), let a3 = UserDefaults.standard.string(forKey: "a3") {
        let shoeResultKey = "\(a1)\(a2)\(a3)"
        let shoeResult = shoe[shoeResultKey]
        return shoeResult!
    }
    
    return "error"
}

func removeShoeResult() {
    UserDefaults.standard.removeObject(forKey: "a1")
    UserDefaults.standard.removeObject(forKey: "a2")
    UserDefaults.standard.removeObject(forKey: "a3")
}

func getShoeResultKey() -> String {
    if let a1 = UserDefaults.standard.string(forKey: "a1"), let a2 = UserDefaults.standard.string(forKey: "a2"), let a3 = UserDefaults.standard.string(forKey: "a3") {
        let shoeResultKey = "\(a1)\(a2)\(a3)"
        return shoeResultKey
    }
    
    return "error"
}
