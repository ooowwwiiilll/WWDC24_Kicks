import SwiftUI
import AVKit

extension View {
    func bigTitle() -> some View {
        self.modifier(BigTitle())
    }
}

struct BigTitle: ViewModifier {
    func body(content: Content) -> some View {
        content
            .font(.custom("Helvetica", size: 60))
            .kerning(-1)
    }
}

extension View {
    func buTitle() -> some View {
        self.modifier(BuTitle())
    }
}

struct BuTitle: ViewModifier {
    func body(content: Content) -> some View {
        content
            .font(.custom("Helvetica", size: 36))
            .kerning(-1)
    }
}

extension View {
    func title1() -> some View {
        self.modifier(Title1())
    }
}

struct Title1: ViewModifier {
    func body(content: Content) -> some View {
        content
            .font(.custom("Helvetica", size: 44))
            .kerning(-1)
    }
}

extension View {
    func quizTitle() -> some View {
        self.modifier(QuizTitle())
    }
}

struct QuizTitle: ViewModifier {
    func body(content: Content) -> some View {
        content
            .font(.custom("Helvetica", size: 32))
            .kerning(1)
            .foregroundStyle(.black.opacity(0.8))
            .rotationEffect(.degrees(-90))
            .fixedSize()
    }
}

extension View {
    func smallTitle() -> some View {
        self.modifier(SmallTitle())
    }
}

struct SmallTitle: ViewModifier {
    func body(content: Content) -> some View {
        content
            .font(.custom("Helvetica", size: 12))
            .kerning(1)
    }
}

extension View {
    func bodyy() -> some View {
        self.modifier(Bodyy())
    }
}

struct Bodyy: ViewModifier {
    func body(content: Content) -> some View {
        content
            .font(.custom("Helvetica", size: 24))
            .kerning(-1)
    }
}

class SoundManager {
  static let instance = SoundManager()
  var player : AVAudioPlayer?
  enum SoundOption: String {
    case BGM
  }
  
  func playSound(sound: SoundOption) {
    guard let url = Bundle.main.url(forResource: sound.rawValue, withExtension: ".mp3") else { return }
    do {
      player = try AVAudioPlayer(contentsOf: url)
      player?.numberOfLoops = -1
      player?.play()
    }
    catch _ {
      print("error sfx")
    }
  }
}

