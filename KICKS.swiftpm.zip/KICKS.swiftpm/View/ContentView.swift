import SwiftUI
import SceneKit

@available(iOS 17.0, *)
struct ContentView: View {
    @State var isStarted = false
    
    var body: some View {
        ZStack {
            IntroView()
            
            ZStack {
                Color("IVORY").ignoresSafeArea()
                
                VStack(spacing: 60) {
                    Text("THANK YOU 4 \nVISITING THIS PROJECT! ")
                        .bigTitle()
                        .multilineTextAlignment(.center)
                    
                    Text("note: please consider re-running \nif a bug arrives <3")
                        .buTitle()
                        .multilineTextAlignment(.center)
                        .opacity(0.2)
                    
                    Button {
                        withAnimation(.spring) {
                            isStarted.toggle()
                        }
                    } label: {
                        Text("LET'S GO")
                            .foregroundStyle(Color("IVORY"))
                            .title1()
                            .padding(.horizontal, 30)
                            .padding(.vertical, 15)
                            .background(Color("BLUE"))
                            .cornerRadius(100)
                    }
                }
            }
            .opacity(isStarted ? 0 : 1)
        }
    }
}
