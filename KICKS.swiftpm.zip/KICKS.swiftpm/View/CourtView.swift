import SwiftUI
import SceneKit
import Combine

let scene0 = type(of: SCNScene()).init(named: "COURT.scn")
let sceneView0 = SCNView()


class Coordinator: NSObject, UIGestureRecognizerDelegate, ObservableObject {
    var sceneView: SCNView?
    var selectedNode: Binding<SCNNode?>?
    var originalMaterial: Binding<SCNMaterial?>?
    @Published var hitNodeName: String? = nil
    
    init(sceneView: SCNView) {
        self.sceneView = sceneView
        super.init()
    }
    
    @objc func handleTap(_ gestureRecognizer: UITapGestureRecognizer) {
        guard let sceneView = sceneView,
              let selectedNode = selectedNode,
              let originalMaterial = originalMaterial else {
            return
        }

        let location = gestureRecognizer.location(in: sceneView)
        
        if let hitResult = sceneView.hitTest(location, options: nil).first {
            let hitNode = hitResult.node
            
            if let prevNode = selectedNode.wrappedValue, let prevMaterial = originalMaterial.wrappedValue {
                prevNode.geometry?.firstMaterial = prevMaterial
            }
            
            if originalMaterial.wrappedValue == nil {
                originalMaterial.wrappedValue = hitNode.geometry?.firstMaterial
            }
            
            selectedNode.wrappedValue = hitNode
            
            let redMaterial = SCNMaterial()
            redMaterial.diffuse.contents = UIColor(Color("BOOK"))
            hitNode.geometry?.firstMaterial = redMaterial
            
            print(hitNode.name ?? "Unnamed")
            hitNodeName = hitNode.name
            
            if hitNode.name == "PAINT" {
                SCNTransaction.begin()
                SCNTransaction.animationDuration = anim1
                sceneView0.pointOfView = sceneView0.scene?.rootNode.childNode(withName: "cameraP", recursively: true)
                SCNTransaction.commit()
            } else if hitNode.name == "3PT" {
                SCNTransaction.begin()
                SCNTransaction.animationDuration = anim1
                sceneView0.pointOfView = sceneView0.scene?.rootNode.childNode(withName: "camera3", recursively: true)
                SCNTransaction.commit()
            } else if hitNode.name == "MIDY" {
                SCNTransaction.begin()
                SCNTransaction.animationDuration = anim1
                sceneView0.pointOfView = sceneView0.scene?.rootNode.childNode(withName: "cameraM", recursively: true)
                SCNTransaction.commit()
            }
        }
        
    }
    
    func nodeNameForHitTest(at location: CGPoint) -> String? {
            guard let sceneView = sceneView else {
                return nil
            }
            
            if let hitResult = sceneView.hitTest(location, options: nil).first {
                let hitNode = hitResult.node
                return hitNode.name
            }
            
            return nil
        }
    
}

struct CourtView: UIViewRepresentable {
    @State private var selectedNode: SCNNode?
    @State private var originalMaterial: SCNMaterial?
    var coordinator: Coordinator
    
    func makeCoordinator() -> Coordinator {
        return Coordinator(sceneView: sceneView0)
    }
    
    func makeUIView(context: Context) -> some UIView {
        sceneView0.scene = scene0
        
        SCNTransaction.begin()
        SCNTransaction.animationDuration = 2.0
        sceneView0.pointOfView = sceneView0.scene?.rootNode.childNode(withName: "camera", recursively: true)
        sceneView0.pointOfView = sceneView0.scene?.rootNode.childNode(withName: "camera2", recursively: true)
        SCNTransaction.commit()
        
        let tapGesture = UITapGestureRecognizer(target: context.coordinator, action: #selector(Coordinator.handleTap(_:)))
        sceneView0.addGestureRecognizer(tapGesture)
        
        context.coordinator.selectedNode = $selectedNode
        context.coordinator.originalMaterial = $originalMaterial
        
        func nodeNameForHitTest(at location: CGPoint) -> String? {
            return context.coordinator.nodeNameForHitTest(at: location)
        }
        
        return sceneView0
    }
    
    func updateUIView(_ uiView: UIViewType, context: Context) {
        
    }
}

