import SwiftUI

struct IntroView: View {
    @State private var opacity01 =  1.0
    @State private var opacity02 =  0.0
    @State private var opacity03 =  0.0
    @State private var showIntro = 0.0
    
    let haptic = UIImpactFeedbackGenerator()
    let topSpec: CGFloat = 255
    let timer = Timer.publish(every:  0.4, on: .main, in: .common).autoconnect()
    let thick: CGFloat = 5
    
    var body: some View {
        NavigationStack {
            ZStack {
                VStack(spacing: 30) {
                    HStack {
                        ZStack {
                            Image("03")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(width: topSpec)
                                .opacity(opacity03)
                                .animation(.spring(duration:  0.2), value: opacity03)
                            Image("02")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(width: topSpec)
                                .opacity(opacity02)
                                .animation(.spring(duration:  0.2), value: opacity02)
                            Image("01")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(width: topSpec)
                                .opacity(opacity01)
                                .animation(.spring(duration:  0.2), value: opacity01)
                        }
                        .blendMode(.darken)
                        .onReceive(timer) { _ in
                            if opacity01 ==  1.0 {
                                opacity01 =  0.0
                                opacity02 =  1.0
                            } else if opacity02 ==  1.0 {
                                opacity02 =  0.0
                                opacity03 =  1.0
                            } else {
                                opacity03 =  0.0
                                opacity01 =  1.0
                            }
                        }
                        
                        Spacer()
                    }
                    
                    Spacer()
                    
                    HStack {
                        Text("WWDC")
                        Spacer()
                        Text("2K24")
                    }
                    .bigTitle()
                    .foregroundColor(Color("BLUE"))
                    
                    Rectangle()
                        .fill(Color("BLUE"))
                        .frame(height: thick)
                    
                    Image("KICKS")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                    
                    ZStack(alignment: .top) {
                        Rectangle()
                            .fill(Color("BLUE"))
                            .frame(height: thick)
                        
                        HStack(alignment: .bottom, spacing: 30) {
                            NavigationLink {
                                QuizView()
                            } label: {
                                Text("JUMP TO LAB")
                                    .foregroundStyle(Color("BLUE"))
                                    .title1()
                                    .padding(.horizontal, 30)
                                    .padding(.vertical, 15)
                                    .background(Color("IVORY"))
                                    .cornerRadius(100)
                                    .overlay(
                                    RoundedRectangle(cornerRadius: 100)
                                    .inset(by: 2)
                                    .stroke(Color("BLUE"), lineWidth: thick)
                                    )
                            }
                            
                            Rectangle()
                                .fill(Color("BLUE"))
                                .frame(width:thick, height: 104)
                            
                            NavigationLink {
                                StoryView()
                            } label: {
                                HStack {
                                    Text("GET STARTED")
                                        .title1()
                                    Image(systemName: "arrow.right")
                                        .font(.largeTitle)
                                }
                                .foregroundStyle(Color("IVORY"))
                                .padding(.horizontal, 30)
                                .padding(.vertical, 15)
                                .background(Color("BLUE"))
                                .cornerRadius(100)
                            }
                            
                            Spacer()
                        }
                    }
                }
                .padding(.horizontal, 60)
                .padding(.vertical, 30)
                .opacity(showIntro)
                .onAppear() {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
                        withAnimation(.spring) {
                            showIntro = 1
                        }
                    }
                }

            }
            .navigationBarBackButtonHidden()
            .navigationTitle("")
            .background(Color("IVORY"))
            .onAppear() {
                SoundManager.instance.playSound(sound: .BGM)
            }
        }
    }
}

struct IntroViewPreview: PreviewProvider {
    static var previews: some View {
        IntroView()
            .previewInterfaceOrientation(.landscapeLeft)
    }
}


