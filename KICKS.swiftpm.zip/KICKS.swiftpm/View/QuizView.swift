import SwiftUI
import SceneKit

struct QuizView: View {
    @State var q1 = false
    @State var q2 = false
    @State var q3 = false
    @State var q4 = false
    @State var firstIndex = true
    
    @State var select1a = false
    @State var select1b = false
    @State var select1c = false
    
    @State var select2a = false
    @State var select2b = false
    @State var select2c = false
    
    @State var select3a = false
    @State var select3b = false
    @State var select3c = false
    
    @State var showQuiz = false
    @State var quizScale = true
    @StateObject var coordinator = Coordinator(sceneView: sceneView0)
    
    private let color: Color = Color("BLUE")
    let greeen = Color("BOOK")
    let greeen2 = Color.black.opacity(0.3)
    let orangee = Color("BOOK")
    @State private var offset: CGFloat = 0
    var rectSize = CGSize(width: 300, height: 50)
    var rectSize2 = CGSize(width: 300, height: 25)
    var circleSize: CGFloat = 50
    @GestureState var isDragging: Bool = false
    @State var previousOffset: CGFloat = 0
    @State private var isBeating: Bool = false
    let haptic = UIImpactFeedbackGenerator()
    
    let bar : CGFloat = 90
    let thick: CGFloat = 5
    let bookfade = LinearGradient(
        stops: [
            Gradient.Stop(color: Color("BOOK"), location: 0.70),
            Gradient.Stop(color: Color("BOOK").opacity(0.6), location: 1.00),
        ],
        startPoint: UnitPoint(x: 0, y: 0.5),
        endPoint: UnitPoint(x: 1, y: 0.5)
    )
    
    var body: some View {
        NavigationStack {
            ZStack {
                Image("CHECKER")
                    .resizable()
                    .aspectRatio(contentMode: .fill)
                    .ignoresSafeArea()
                
                ZStack {
                    VStack(spacing: 0) {
                        HStack {
                            Text("LAB")
                            Spacer()
                            Text("02")
                        }
                        .padding([.top, .bottom], 30)
                        .bigTitle()
                        .foregroundColor(Color("BOOK"))
                        
                        Rectangle()
                            .fill(Color("BOOK"))
                            .frame(height: thick)
                        
                        HStack(spacing: 0) {
                            if !q1 && !q2 && !q3 && !q4 {
                                ZStack {
                                    Color("BOOK").opacity(0.3)
                                    
                                    VStack(alignment: .leading) {
                                        HStack {
                                            Text("LET'S START A QUIZ → \n \nANSWER THESE 3 SIMPLE QUESTIONS \nTO GET YOUR EXCLUSIVE KICKS!")
                                                .foregroundStyle(.white)
                                                .buTitle()
                                            Spacer()
                                        }
                                        
                                        Spacer()
                                        
                                        Button{
                                            withAnimation(.spring){
                                                q4.toggle()
                                                firstIndex.toggle()
                                                haptic.impactOccurred()
                                            }
                                        } label: {
                                            Text("START QUIZ")
                                                .foregroundStyle(Color("BOOK"))
                                                .title1()
                                                .padding(.horizontal, 30)
                                                .padding(.vertical, 15)
                                                .cornerRadius(100)
                                                .overlay(
                                                RoundedRectangle(cornerRadius: 100)
                                                .inset(by: 2)
                                                .stroke(Color("BOOK"), lineWidth: thick)
                                                )
                                        }
                                    }
                                    .padding(30)
                                }
                            }
                            
                            VStack {
                                Spacer()
                                Text("HOT ZONE")
                                    .quizTitle()
                                Spacer()
                            }
                            .frame(width: bar)
                            .background(bookfade)
                            .onTapGesture {
                                withAnimation(.spring) {
                                    q4.toggle()
                                    q1 = false
                                    q2 = false
                                    q3 = false
                                }
                            }
                            
                            ZStack {
                                CourtView(coordinator: coordinator)
                                    .blendMode(.lighten)
                                    .opacity(0.9)
                                
                                VStack(alignment: .leading) {
                                    HStack {
                                        Text("\nTAP THE COURT AREA WHERE YOU \nDID MOST OF YOUR DAMAGE")
                                            .foregroundStyle(.white)
                                            .buTitle()
                                        Spacer()
                                    }
                                    
                                    Spacer()
                                    
                                    Text("INNER BOX → PAINT AREA \nHALF CIRCLE → MID RANGE \nOUTSIDE HALF CIRCLE → 3PT RANGE")
                                        .smallTitle()
                                        .foregroundColor(.white)
                                        .padding(15)
                                        .background(Color.black.opacity(0.6))
                                        .cornerRadius(15)
                                        .padding(.bottom, 15)
                                    
                                    HStack {
                                        Button{
                                            withAnimation(.spring){
                                                firstIndex = true
                                                q1 = false
                                                q4 = false
                                                haptic.impactOccurred()
                                            }
                                        } label: {
                                            Text("BACK")
                                                .foregroundStyle(Color("BOOK"))
                                                .buTitle()
                                                .padding(.horizontal, 30)
                                                .padding(.vertical, 15)
                                                .background(.black.opacity(0.15))
                                                .cornerRadius(100)
                                                .overlay(
                                                RoundedRectangle(cornerRadius: 100)
                                                .inset(by: 2)
                                                .stroke(Color("BOOK"), lineWidth: thick)
                                                )
                                        }
                                        
                                        Button{
                                            withAnimation(.spring){
                                                q1.toggle()
                                                q4 = false
                                                haptic.impactOccurred()
                                            }
                                        } label: {
                                            Text("NEXT")
                                                .foregroundStyle(Color("BOOK"))
                                                .buTitle()
                                                .padding(.horizontal, 30)
                                                .padding(.vertical, 15)
                                                .background(.black.opacity(0.15))
                                                .cornerRadius(100)
                                                .overlay(
                                                RoundedRectangle(cornerRadius: 100)
                                                .inset(by: 2)
                                                .stroke(Color("BOOK"), lineWidth: thick)
                                                )
                                        }
                                    }
                                }
                                .padding(30)
                            }
                            .opacity(q4 ? 1 : 0)
                            .frame(width: q4 ? nil : 0)
                            
                            VStack {
                                Spacer()
                                Text("IDENTITY")
                                    .quizTitle()
                                Spacer()
                            }
                            .frame(width: bar)
                            .background(bookfade)
                            .onTapGesture {
                                withAnimation(.spring) {
                                    q1.toggle()
                                    q2 = false
                                    q3 = false
                                    q4 = false
                                }
                            }
                            
                            ZStack {
                                Color("BOOK").opacity(0.3)
                                
                                VStack(alignment: .leading) {
                                    HStack {
                                        Text("\nWHAT POSITION YOU EMBRACE THE MOST?")
                                            .foregroundStyle(.white)
                                            .buTitle()
                                        Spacer()
                                    }
                                    
                                    Text("SELECT A CARD")
                                        .smallTitle()
                                        .padding(.top, 15)
                                        .foregroundColor(.white)
                                    
                                    Spacer()
                                    
                                    HStack(spacing: 0) {
                                        Spacer()
                                        
                                        Button {
                                            let haptic = UIImpactFeedbackGenerator()
                                            UserDefaults.standard.set("B", forKey: "a1")
                                            withAnimation(.spring) {
                                                select1a.toggle()
                                                select1b = false
                                                select1c = false
                                            }
                                        } label: {
                                            Image("P34")
                                                .resizable()
                                                .aspectRatio(contentMode: .fit)
                                        }
                                        .scaleEffect(select1a ? 1.1 : 0.8)
                                        .rotationEffect(Angle(degrees: -3))
                                        .offset(y: 15)
                                        .opacity(select1a ? 1 : 0.6)
                                        
                                        
                                        Button {
                                            let haptic = UIImpactFeedbackGenerator()
                                            UserDefaults.standard.set("H", forKey: "a1")
                                            withAnimation(.spring) {
                                                select1b.toggle()
                                                select1a = false
                                                select1c = false
                                            }
                                        } label: {
                                            Image("P12")
                                                .resizable()
                                                .aspectRatio(contentMode: .fit)
                                        }
                                        .scaleEffect(select1b ? 1.1 : 0.8)
                                        .opacity(select1b ? 1 : 0.6)
                                        
                                        
                                        Button {
                                            let haptic = UIImpactFeedbackGenerator()
                                            UserDefaults.standard.set("L", forKey: "a1")
                                            withAnimation(.spring) {
                                                select1c.toggle()
                                                select1b = false
                                                select1a = false
                                            }
                                        } label: {
                                            Image("P5")
                                                .resizable()
                                                .aspectRatio(contentMode: .fit)
                                        }
                                        .scaleEffect(select1c ? 1.1 : 0.8)
                                        .rotationEffect(Angle(degrees: 6))
                                        .offset(y: 30)
                                        .opacity(select1c ? 1 : 0.6)
                                        
                                        
                                        Spacer()
                                    }
                                    .font(.system(size: 30))
                                    .foregroundColor(.white)
                                    
                                    Spacer()
                                    
                                    HStack {
                                        Button{
                                            withAnimation(.spring){
                                                firstIndex = true
                                                q1 = false
                                                q4 = true
                                                haptic.impactOccurred()
                                            }
                                        } label: {
                                            Text("BACK")
                                                .foregroundStyle(Color("BOOK"))
                                                .buTitle()
                                                .padding(.horizontal, 30)
                                                .padding(.vertical, 15)
                                                .background(.black.opacity(0.15))
                                                .cornerRadius(100)
                                                .overlay(
                                                RoundedRectangle(cornerRadius: 100)
                                                .inset(by: 2)
                                                .stroke(Color("BOOK"), lineWidth: thick)
                                                )
                                        }
                                        
                                        Button {
                                            withAnimation(.spring){
                                                q2.toggle()
                                                q1 = false
                                                haptic.impactOccurred()
                                            }
                                        } label: {
                                            Text("NEXT")
                                                .foregroundStyle(Color("BOOK"))
                                                .buTitle()
                                                .padding(.horizontal, 30)
                                                .padding(.vertical, 15)
                                                .background(.black.opacity(0.15))
                                                .cornerRadius(100)
                                                .overlay(
                                                RoundedRectangle(cornerRadius: 100)
                                                .inset(by: 2)
                                                .stroke(Color("BOOK"), lineWidth: thick)
                                                )
                                        }
                                        .disabled(canGoNext())
                                    }
                                }
                                .padding(30)
                                
                            }
                            .opacity(q1 ? 1 : 0)
                            .frame(width: q1 ? nil : 0)

                            VStack {
                                Spacer()
                                Text("DEFENSE")
                                    .quizTitle()
                                Spacer()
                            }
                            .frame(width: bar)
                            .background(bookfade)
                            .onTapGesture {
                                withAnimation(.spring) {
                                    q2.toggle()
                                    q1 = false
                                    q3 = false
                                    q4 = false
                                }
                            }
                            
                            ZStack {
                                Color("BOOK").opacity(0.3)
                                
                                VStack(alignment: .leading) {
                                    HStack {
                                        Text("\nWHO DID YOU DEFEND THE MOST?")
                                            .foregroundStyle(.white)
                                            .buTitle()
                                        Spacer()
                                    }
                                    
                                    Text("SELECT A CARD")
                                        .smallTitle()
                                        .padding(.top, 15)
                                        .foregroundColor(.white)
                                    
                                    Spacer()
                                    
                                    HStack(spacing: 0) {
                                        Spacer()
                                        
                                        Button {
                                            let haptic = UIImpactFeedbackGenerator()
                                            UserDefaults.standard.set("1", forKey: "a2")
                                            withAnimation(.spring) {
                                                select2a.toggle()
                                                select2b = false
                                                select2c = false
                                            }
                                        } label: {
                                            Image("P34")
                                                .resizable()
                                                .aspectRatio(contentMode: .fit)
                                        }
                                        .scaleEffect(select2a ? 1.1 : 0.8)
                                        .rotationEffect(Angle(degrees: -3))
                                        .offset(y: 15)
                                        .opacity(select2a ? 1 : 0.4)
                                        
                                        
                                        Button {
                                            let haptic = UIImpactFeedbackGenerator()
                                            UserDefaults.standard.set("2", forKey: "a2")
                                            withAnimation(.spring) {
                                                select2b.toggle()
                                                select2a = false
                                                select2c = false
                                            }
                                        } label: {
                                            Image("P12")
                                                .resizable()
                                                .aspectRatio(contentMode: .fit)
                                        }
                                        .scaleEffect(select2b ? 1.1 : 0.8)
                                        .opacity(select2b ? 1 : 0.4)
                                        
                                        
                                        Button {
                                            let haptic = UIImpactFeedbackGenerator()
                                            UserDefaults.standard.set("3", forKey: "a2")
                                            withAnimation(.spring) {
                                                select2c.toggle()
                                                select2b = false
                                                select2a = false
                                            }
                                        } label: {
                                            Image("P5")
                                                .resizable()
                                                .aspectRatio(contentMode: .fit)
                                        }
                                        .scaleEffect(select2c ? 1.1 : 0.8)
                                        .rotationEffect(Angle(degrees: 6))
                                        .offset(y: 30)
                                        .opacity(select2c ? 1 : 0.4)
                                        
                                        
                                        Spacer()
                                    }
                                    .blendMode(.overlay)
                                    .font(.system(size: 30))
                                    .foregroundColor(.white)
                                    
                                    Spacer()
                                    
                                    HStack {
                                        Button{
                                            withAnimation(.spring){
                                                firstIndex = true
                                                q1 = true
                                                q2 = false
                                                haptic.impactOccurred()
                                            }
                                        } label: {
                                            Text("BACK")
                                                .foregroundStyle(Color("BOOK"))
                                                .buTitle()
                                                .padding(.horizontal, 30)
                                                .padding(.vertical, 15)
                                                .background(.black.opacity(0.15))
                                                .cornerRadius(100)
                                                .overlay(
                                                RoundedRectangle(cornerRadius: 100)
                                                .inset(by: 2)
                                                .stroke(Color("BOOK"), lineWidth: thick)
                                                )
                                        }
                                        
                                        Button {
                                            withAnimation(.spring){
                                                q2 = false
                                                q3.toggle()
                                                haptic.impactOccurred()
                                            }
                                            
                                        } label: {
                                            Text("NEXT")
                                                .foregroundStyle(Color("BOOK"))
                                                .buTitle()
                                                .padding(.horizontal, 30)
                                                .padding(.vertical, 15)
                                                .background(.black.opacity(0.15))
                                                .cornerRadius(100)
                                                .overlay(
                                                RoundedRectangle(cornerRadius: 100)
                                                .inset(by: 2)
                                                .stroke(Color("BOOK"), lineWidth: thick)
                                                )
                                        }
                                        .disabled(canGoNext())
                                    }
                                }
                                .padding(30)
                                
                            }
                            .opacity(q2 ? 1 : 0)
                            .frame(width: q2 ? nil : 0)

                            VStack {
                                Spacer()
                                Text("INTENSITY")
                                    .quizTitle()
                                Spacer()
                            }
                            .frame(width: bar)
                            .background(bookfade)
                            .onTapGesture {
                                withAnimation(.spring) {
                                    q3.toggle()
                                    q1 = false
                                    q2 = false
                                    q4 = false
                                }
                            }
                            
                            ZStack {
                                Color("BOOK").opacity(0.3)
                                
                                VStack(alignment: .leading) {
                                    HStack {
                                        Text("\nWHAT'S YOUR PLAY STYLE UN-INTENSITY?")
                                            .foregroundStyle(.white)
                                            .buTitle()
                                        Spacer()
                                    }
                                    
                                    Text("DRAG THE SLIDER HORIZONTALLY")
                                        .smallTitle()
                                        .padding(.top, 15)
                                        .foregroundColor(.white)
                                    
                                    Spacer()
                                    
                                    VStack {
                                        slider
                                            .scaleEffect(2)
                                        
                                        HStack(spacing: 90) {
                                            Text("HIGH")
                                            Text("MEDIUM")
                                            Text("SLOW")
                                        }
                                        .title1()
                                        .foregroundStyle(.white)
                                        .padding(.top, 60)
                                    }
                                    
                                    Spacer()
                                    
                                    Button{
                                        withAnimation(.spring){
                                            firstIndex = true
                                            q2 = true
                                            q3 = false
                                            haptic.impactOccurred()
                                        }
                                    } label: {
                                        Text("BACK")
                                            .foregroundStyle(Color("BOOK"))
                                            .buTitle()
                                            .padding(.horizontal, 30)
                                            .padding(.vertical, 15)
                                            .background(.black.opacity(0.15))
                                            .cornerRadius(100)
                                            .overlay(
                                            RoundedRectangle(cornerRadius: 100)
                                            .inset(by: 2)
                                            .stroke(Color("BOOK"), lineWidth: thick)
                                            )
                                    }
                                    
                                }
                                .padding(30)
                                
                            }
                            .opacity(q3 ? 1 : 0)
                            .frame(width: q3 ? nil : 0)
                            
                        }
                        .ignoresSafeArea()
                        .opacity(showQuiz ? 1 : 0)
                        .scaleEffect(quizScale ? 1.4 : 1.0)
                        
                        ZStack(alignment: .top) {
                            Rectangle()
                                .fill(Color("BOOK"))
                                .frame(height: thick)
                            
                            HStack(alignment: .bottom, spacing: 30) {
                                Spacer()
                                
                                Rectangle()
                                    .fill(Color("BOOK"))
                                    .frame(width:thick, height: 104)
                                    .opacity(0)
                                
                                if q3 {
                                    withAnimation(.spring) {
                                        NavigationLink {
                                            ResultView()
                                        } label: {
                                            HStack {
                                                Text("REVEAL MY SHOE")
                                                    .title1()
                                                Image(systemName: "arrow.right")
                                                    .font(.largeTitle)
                                            }
                                            .foregroundColor(.black.opacity(0.8))
                                            .padding(.horizontal, 30)
                                            .padding(.vertical, 15)
                                            .background(Color("BOOK"))
                                            .cornerRadius(100)
                                            .frame(height: q3 ? nil : 0)
                                        }
                                    }
                                }
                                
                            }
                        }
                    }
                    .padding(.horizontal, 60)
                    .padding(.vertical, 30)

                }
                .onAppear() {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                        withAnimation(.spring) {
                            showQuiz = true
                            quizScale = false
                        }
                    }
                }

            }
            .navigationBarBackButtonHidden()
            .navigationTitle("")
        }
    }
    
    func canGoNext() -> Bool {
        if select1a || select1b || select1c {
            return false
        }
        
        if select2a || select2b || select2c {
            return false
        }
        
        if select3a || select3b || select3c {
            return false
        }
        
        return true
    }
    
    var percentage: Int {
        Int((offset) / (rectSize.width - circleSize) * 100)
    }
    
    private var slider: some View {
        ZStack {
            Canvas { context, size in
                context.addFilter(.alphaThreshold(min: 0.5, max: 1, color: greeen2))
                context.addFilter(.blur(radius: 6))
                
                context.drawLayer { ctx in
                    if let rectangle = ctx.resolveSymbol(id: "Rectangle") {
                        ctx.draw(rectangle, at: CGPoint(x: size.width/2, y: size.height/2))
                    }
                    if let circle = ctx.resolveSymbol(id: "Circle") {
                        ctx.draw(circle, at: CGPoint(x: size.width/2 - rectSize2.width/2 + circleSize/2, y: size.height/2))
                    }
                }
            } symbols: {
                Rectangle()
                    .frame(width: rectSize2.width, height: rectSize2.height, alignment: .center)
                    .tag("Rectangle")
                Circle()
                    .frame(width: circleSize * 1.2, height: circleSize * 1.2, alignment: .center)
                    .offset(x: offset)
                    .animation(.spring(), value: isDragging)
                    .tag("Circle")
            }
            
            Canvas { context, size in
                context.addFilter(.alphaThreshold(min: 0.5, max: 1, color: greeen))
                context.addFilter(.blur(radius: 4))
                
                context.drawLayer { ctx in
                    if let rectangle = ctx.resolveSymbol(id: "Rectangle") {
                        ctx.draw(rectangle, at: CGPoint(x: size.width/2, y: size.height/2))
                    }
                    if let circle = ctx.resolveSymbol(id: "Circle") {
                        ctx.draw(circle, at: CGPoint(x: size.width/2 - rectSize2.width/2 + circleSize/2, y: size.height/2))
                    }
                }
            } symbols: {
                Rectangle()
                    .frame(width: rectSize2.width / 1.5, height: rectSize2.height, alignment: .center)
                    .tag("Rectangle")
                Circle()
                    .frame(width: circleSize * 1.2, height: circleSize * 1.2, alignment: .center)
                    .offset(x: offset)
                    .animation(.spring(), value: isDragging)
                    .tag("Circle")
            }
            
            //MARK: HITAM
            
            Canvas { context, size in
                context.addFilter(.alphaThreshold(min: 0.5, max: 1, color: Color.black.opacity(0.9)))
                context.addFilter(.blur(radius: 4))
                
                context.drawLayer { ctx in
                    if let rectangle = ctx.resolveSymbol(id: "Rectangle") {
                        ctx.draw(rectangle, at: CGPoint(x: size.width/2, y: size.height/2))
                    }
                    if let circle = ctx.resolveSymbol(id: "Circle") {
                        ctx.draw(circle, at: CGPoint(x: size.width/2 - rectSize2.width/2 + circleSize/2, y: size.height/2))
                    }
                }
            } symbols: {
                Rectangle()
                    .frame(width: rectSize2.width / 2, height: rectSize2.height/2, alignment: .center)
                    .tag("Rectangle")
                Circle()
                    .frame(width: circleSize, height: circleSize, alignment: .center)
                    .offset(x: offset)
                    .animation(.spring(), value: isDragging)
                    .tag("Circle")
            }
            
            Circle()
                .fill(orangee)
                .frame(width: circleSize - 14)
                .overlay {
                    Text("\(percentage)")
                        .font(.system(size: 16, weight: .semibold, design: .rounded))
                        .foregroundColor(.black)
                        .contentTransition(.numericText(value: Double(percentage)))
                        
                }
                .offset(x: (-rectSize2.width/2) + (circleSize/2))
                .offset(x: offset)
                .animation(.spring(), value: isDragging)
                .allowsHitTesting(false)
                .onAppear {
                    withAnimation(.easeInOut(duration: 0.5).repeatForever()) {
                    }
                }
        }
        .frame(height: 100)
        .simultaneousGesture(
            DragGesture(minimumDistance: 0)
                .updating($isDragging, body: { _, state, _ in
                    state = true
                })
                .onChanged({ value in
                    self.offset = min(max(self.previousOffset + value.translation.width, 0), rectSize2.width - circleSize)
                })
                .onEnded({ value in
                    let totalWidth = rectSize2.width - circleSize
                    let quarterWidth = totalWidth / 2
                    let snappedOffset = round(self.offset / quarterWidth) * quarterWidth
                    self.offset = min(max(snappedOffset, 0), totalWidth)
                    self.previousOffset = self.offset
                    haptic.impactOccurred()
                    print(percentage)
                    print(getShoeResultKey())
                    if percentage <= 33 {
                        UserDefaults.standard.set("A", forKey: "a3")
                    }
                    
                    if percentage >= 34 && percentage <= 65 {
                        UserDefaults.standard.set("P", forKey: "a3")
                    }
                    if percentage >= 66 {
                        UserDefaults.standard.set("S", forKey: "a3")
                    }
                })
        )
    }
    
}

struct QuizViewPreview: PreviewProvider {
    static var previews: some View {
        QuizView()
            .previewInterfaceOrientation(.landscapeLeft)
    }
}

