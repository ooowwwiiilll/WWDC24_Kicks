import SwiftUI
import UIKit

struct ResultView: View {
    @State var upperC: Color = .white
    @State var overlayC: Color = .white
    @State var midsoleC: Color = .white
    @State var outsoleC: Color = .white
    @State var revealed = false
    @State var titleFade: Double = 0
    @State var showCard = false
    let haptic = UIImpactFeedbackGenerator()
    
    var body: some View {
        NavigationStack {
            ZStack(alignment: .center) {
                Image("CHECKER2")
                    .resizable()
                    .aspectRatio(contentMode: .fill)
                    .ignoresSafeArea()
                
                HStack(spacing: 15) {
                    VStack(spacing: 15) {
                        ZStack {
                            ZStack {
                                if getShoeResult() == "SB1" {
                                    ShoeView1()
                                } else if getShoeResult() == "SB2" {
                                    ShoeView2()
                                } else if getShoeResult() == "SB3" {
                                    ShoeView3()
                                }
                            }
                            .opacity(0.9)
                            .ignoresSafeArea()
                            
                            VStack(spacing: 0) {
                                
                                Text("HELLO THERE, MR. \(getName())!")
                                    .bigTitle()
                                    .foregroundColor(Color("IVORY"))
                                    .padding(.top, 60)
                                    .onAppear() {
                                        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
                                            withAnimation(.spring) {
                                                titleFade = 1
                                            }
                                        }
                                    }
                                
                                Text("PINCH & DRAG TO LOOK AROUND. MOVE WITH 2 FINGERS.")
                                    .smallTitle()
                                    .foregroundColor(Color("IVORY"))
                                    .padding(.top, 15)
                                    .blendMode(.difference)
                                    .opacity(revealed ? 1 : 0)
                                
                                Spacer()
                                
                                HStack (alignment: .top, spacing: 60) {
                                    if getShoeResult() == "SB1" {
                                        Group {
                                            VStack(alignment: .leading, spacing: 15) {
                                                Text("YOU GOT KICKS NO.1").bold()
                                                    .foregroundStyle(Color("BOOK"))
                                                    .bodyy()
                                                Text("YOU OFTEN MOVES LATERALY. KICKS NO.1 ASSISTS YOUR MOVEMENTS")
                                            }
                                            
                                            VStack(alignment: .leading, spacing: 15) {
                                                Text("UPPER").bold().bodyy()
                                                Text("SYNTHETIC \nLEATHER")
                                            }
                                            
                                            VStack(alignment: .leading, spacing: 15) {
                                                Text("CUSHION").bold().bodyy()
                                                Text("FIBER POCKETS \nNITRO FOAMS")
                                            }
                                            
                                            VStack(alignment: .leading, spacing: 15) {
                                                Text("TRACTION").bold().bodyy()
                                                Text("CIRCULAR")
                                            }
                                            
                                        }
                                    } else if getShoeResult() == "SB2" {
                                        Group {
                                            VStack(alignment: .leading, spacing: 15) {
                                                Text("YOU GOT KICKS NO.2").bold()
                                                    .foregroundStyle(Color("BOOK"))
                                                    .bodyy()
                                                Text("YOU RELY ON AGILITY. KICKS NO.2 PROVIDE THE COURT FEEL YOU NEED")
                                            }
                                            
                                            VStack(alignment: .leading, spacing: 15) {
                                                Text("UPPER").bold().bodyy()
                                                Text("THIN MESH")
                                            }
                                            
                                            VStack(alignment: .leading, spacing: 15) {
                                                Text("CUSHION").bold().bodyy()
                                                Text("PHYLON FOAM")
                                            }
                                            
                                            VStack(alignment: .leading, spacing: 15) {
                                                Text("TRACTION").bold().bodyy()
                                                Text("HERRINGBONE")
                                            }
                                        }
                                    } else if getShoeResult() == "SB3" {
                                        Group {
                                            VStack(alignment: .leading, spacing: 15) {
                                                Text("YOU GOT KICKS NO.3").bold()
                                                    .foregroundStyle(Color("BOOK"))
                                                    .bodyy()
                                                Text("YOU NEED TO BE STABLE. KICKS NO.3 ENSURES YOU ARE SECURED ")
                                            }
                                            
                                            VStack(alignment: .leading, spacing: 15) {
                                                Text("UPPER").bold().bodyy()
                                                Text("FABRIC")
                                            }
                                            
                                            VStack(alignment: .leading, spacing: 15) {
                                                Text("CUSHION").bold().bodyy()
                                                Text("AIR POCKETS")
                                            }
                                            
                                            VStack(alignment: .leading, spacing: 15) {
                                                Text("TRACTION").bold().bodyy()
                                                Text("HERRINGBONE")
                                            }
                                            
                                        }
                                    }
                                    
                                    Button {
                                        withAnimation(.spring) {
                                            showCard = true
                                        }
                                    } label: {
                                        Text("VIEW \nPOSTER").bold().bodyy()
                                            .multilineTextAlignment(.leading)
                                    }
                                    
                                    Spacer()
                                }
                                .padding(15)
                                .foregroundStyle(Color("IVORY"))
                                .background(Color("IVORY").opacity(0.15))
                                .cornerRadius(5)
                                .padding(15)
                                .opacity(revealed ? 1 : 0)
                            }
                        }
                        .cornerRadius(15)
                        .opacity(titleFade)
                        
                        HStack(spacing: 90) {
                            Spacer()
                            
                            Text("LET'S COLOR YOUR KICKS!")
                                .bold()
                            
                            ColorPicker(selection: $upperC) {
                                Text("UPPER COLOR")
                            }
                            .onChange(of: upperC) { newValue in
                                change(asset: "upper",col: upperC);
                                change(asset: "tongue", col: upperC)
                                upperCamera()
                                upperCamera2()
                                upperCamera3()
                            }
                            
                            if getShoeResult() == "SB1" {
                                ColorPicker(selection: $overlayC) {
                                    Text("OVERLAY COLOR")
                                }
                                .onChange(of: overlayC) { newValue in
                                    change(asset: "overlay",col: overlayC)
                                    upperCamera()
                                    upperCamera2()
                                    upperCamera3()
                                }
                            }
                            
                            ColorPicker(selection: $midsoleC) {
                                Text("MIDSOLE COLOR")
                            }
                            .onChange(of: midsoleC) { newValue in
                                change(asset: "midsole",col: midsoleC);
                                change(asset: "pods",col: midsoleC)
                                midCamera()
                                midCamera2()
                                midCamera3()
                            }
                            
                            ColorPicker(selection: $outsoleC) {
                                Text("OUTS0LE COLOR")
                            }
                            .onChange(of: outsoleC) { newValue in
                                change(asset: "outsole",col: outsoleC);
                                change(asset: "traction",col: outsoleC)
                                lowerCamera()
                                lowerCamera2()
                                lowerCamera3()
                            }
                            
                            Spacer()
                        }
                        .padding(.vertical, 10)
                        .foregroundColor(Color("IVORY"))
                        .background(Color("IVORY").opacity(0.15))
                        .cornerRadius(15)
                        .frame(height: revealed ? nil : 0)
                        .opacity(revealed ? 1 : 0)
                    }
                    
                    VStack(spacing: 90) {
                        Spacer()
                        
                        Button {
                            if getShoeResult() == "SB1" {
                                focus1up()
                            } else if getShoeResult() == "SB2" {
                                focus2up()
                            } else if getShoeResult() == "SB3" {
                                focus3up()
                            }
                            
                        } label: {
                            Image(systemName: "square.3.layers.3d.top.filled")
                        }
                        
                        Button {
                            if getShoeResult() == "SB1" {
                                focus1mid()
                            } else if getShoeResult() == "SB2" {
                                focus2mid()
                            } else if getShoeResult() == "SB3" {
                                focus3mid()
                            }
                            
                        } label: {
                            Image(systemName: "square.3.layers.3d.middle.filled")
                        }
                        
                        Button {
                            if getShoeResult() == "SB1" {
                                focus1low()
                            } else if getShoeResult() == "SB2" {
                                focus2low()
                            } else if getShoeResult() == "SB3" {
                                focus3low()
                            }
                            
                        } label: {
                            Image(systemName: "square.3.layers.3d.bottom.filled")
                        }
                        
                        Spacer()
                        
                        Button {
                            if getShoeResult() == "SB1" {
                                revealShoe1()
                            } else if getShoeResult() == "SB2" {
                                revealShoe2()
                            } else if getShoeResult() == "SB3" {
                                revealShoe3()
                            }
                            
                        } label: {
                            Image(systemName: "arrow.circlepath")
                        }
                        
                        NavigationLink {
                            IntroView()
                        } label: {
                            Image(systemName: "checkmark.circle.fill")
                        }
                        
                        Spacer()
                    }
                    .font(.system(size: 44))
                    .padding(15)
                    .foregroundColor(Color("BLUE"))
                    .background(Color("IVORY"))
                    .cornerRadius(15)
                    .opacity(revealed ? 1 : 0)
                    .frame(width: revealed ? nil : 0)
                }
                .padding(15)
                
                Button {
                    if getShoeResult() == "SB1" {
                        revealShoe1()
                    } else if getShoeResult() == "SB2" {
                        revealShoe2()
                    } else if getShoeResult() == "SB3" {
                        revealShoe3()
                    }
                    
                    withAnimation(.spring(duration: 1.0)) {
                        revealed = true
                    }
                    haptic.impactOccurred()
                    
                } label : {
                    VStack(spacing: 30) {
                        ZStack {
                            Image("box0")
                                .opacity(revealed ? 0 : 1)
                                .offset(y: revealed ? 600 : 0)
                            Image("lid0")
                                .offset(y: revealed ? -1200 : -120)
                        }
                        
                        Text("TAP TO REVEAL YOUR KICKS")
                            .title1()
                            .opacity(revealed ? 0 : 1)
                    }
                    .scaleEffect(0.6)
                    .opacity(titleFade)
                }
                
                if showCard {
                    withAnimation(.spring) {
                        ZStack {
                            Color.black.opacity(0.9)
                            
                            ZStack(alignment: .topTrailing) {
                                Image(getCardname())
                                    .resizable()
                                    .scaleEffect(0.8)
                                
                                Button {
                                    withAnimation(.spring) {
                                        showCard = false
                                    }
                                } label : {
                                    Image(systemName: "xmark.circle")
                                        .font(.system(size: 44))
                                        .padding(60)
                                }
                            }
                        }
                        .ignoresSafeArea()
                    }
                }
                
            }
            .navigationTitle("")
            .navigationBarBackButtonHidden()
            .onAppear() {
                print("\(getShoeResultKey()) → \(getShoeResult())")
            }
        }
    }
}

func change(asset:String,col:Color){
    if getShoeResult() == "SB1" {
        scene1?.rootNode.childNode(withName: asset, recursively: true)?.geometry?.firstMaterial?.diffuse.contents = col.cgColor
    }
    if getShoeResult() == "SB2" {
        scene2?.rootNode.childNode(withName: asset, recursively: true)?.geometry?.firstMaterial?.diffuse.contents = col.cgColor
    }
    if getShoeResult() == "SB3" {
        scene3?.rootNode.childNode(withName: asset, recursively: true)?.geometry?.firstMaterial?.diffuse.contents = col.cgColor
    }
}

public extension UIImage {
  convenience init?(color: UIColor, size: CGSize = CGSize(width: 1, height: 1)) {
    let rect = CGRect(origin: .zero, size: size)
    UIGraphicsBeginImageContextWithOptions(rect.size, false, 0.0)
    color.setFill()
    UIRectFill(rect)
    let image = UIGraphicsGetImageFromCurrentImageContext()
    UIGraphicsEndImageContext()
    guard let cgImage = image?.cgImage else { return nil }
    self.init(cgImage: cgImage)
  }
}

func saveImage(imageName: String) {
    guard let image = UIImage(named: imageName) else {
        print("Image named \(imageName) not found in the asset catalog")
        return
    }
    
    UIImageWriteToSavedPhotosAlbum(image, nil, nil, nil)
}

func getName() -> String {
    if getShoeResult() == "SB1" {
        return "SHIFTY"
    }
    
    if getShoeResult() == "SB2" {
        return "MAESTRO"
    }
    
    if getShoeResult() == "SB3" {
        return "TANK"
    }
    
    return "VERSATILE"
}

struct QuizViewPreview2: PreviewProvider {
    static var previews: some View {
        QuizView()
            .previewInterfaceOrientation(.landscapeLeft)
    }
}

struct ResView: PreviewProvider {
    static var previews: some View {
        ResultView()
            .previewInterfaceOrientation(.landscapeLeft)
    }
}

func getCardname() -> String {
    if getShoeResult() == "SB1" {
        return "Card2"
    }
    
    if getShoeResult() == "SB2" {
        return "Card1"
    }
    
    if getShoeResult() == "SB3" {
        return "Card3"
    }
    
    return "Card3"
}
