import SwiftUI
import SceneKit

let scene1 = type(of: SCNScene()).init(named: "SB1.scn")
let sceneView1 = SCNView()

let upper1 = sceneView1.scene?.rootNode.childNode(withName: "upper", recursively: true)
let midsole1 = sceneView1.scene?.rootNode.childNode(withName: "midsole", recursively: true)
let outsole1 = sceneView1.scene?.rootNode.childNode(withName: "outsole", recursively: true)
let tongue1 = sceneView1.scene?.rootNode.childNode(withName: "tongue", recursively: true)
let overlay1 = sceneView1.scene?.rootNode.childNode(withName: "overlay", recursively: true)
let traction1 = sceneView1.scene?.rootNode.childNode(withName: "traction", recursively: true)
let pods1 = sceneView1.scene?.rootNode.childNode(withName: "pods", recursively: true)
let lid1 = sceneView1.scene?.rootNode.childNode(withName: "lid", recursively: true)
let box1 = sceneView1.scene?.rootNode.childNode(withName: "box", recursively: true)

struct ShoeView1: UIViewRepresentable {
    @State private var selectedNode: SCNNode?
    @State private var originalMaterial: SCNMaterial?
    
    func makeUIView(context: Context) -> SCNView {
        sceneView1.allowsCameraControl = true
        sceneView1.scene = scene1
        sceneView1.pointOfView = sceneView1.scene?.rootNode.childNode(withName: "cameraTOP", recursively: true)
        sceneView1.autoenablesDefaultLighting = true
        sceneView1.cameraControlConfiguration.panSensitivity = 0.3
        sceneView1.cameraControlConfiguration.truckSensitivity = 0.1
        sceneView1.cameraControlConfiguration.rotationSensitivity = 0.1
        sceneView1.cameraControlConfiguration.flyModeVelocity = 0.1
        
        upper1?.geometry?.firstMaterial?.diffuse.contents = Color.white
        tongue1?.geometry?.firstMaterial?.diffuse.contents = Color.white
        overlay1?.geometry?.firstMaterial?.diffuse.contents = Color.white
        midsole1?.geometry?.firstMaterial?.diffuse.contents = Color.white
        pods1?.geometry?.firstMaterial?.diffuse.contents = Color.white
        outsole1?.geometry?.firstMaterial?.diffuse.contents = Color.white
        traction1?.geometry?.firstMaterial?.diffuse.contents = Color.white

        return sceneView1
    }

    func updateUIView(_ uiView: SCNView, context: Context) {

    }
}

//
func expand1() {
    SCNTransaction.begin()
    SCNTransaction.animationDuration = anim1
    sceneView1.pointOfView = sceneView1.scene?.rootNode.childNode(withName: "cameraTOP3", recursively: true)
    upper1?.position.y = 50
    tongue1?.position.y = 50
    overlay1?.position.y = 50
    midsole1?.position.y = 0
    pods1?.position.y = -25
    outsole1?.position.y = -25
    traction1?.position.y = -25
    SCNTransaction.commit()
}

//
func revealShoe1() {
    SCNTransaction.begin()
    SCNTransaction.animationDuration = anim2
    sceneView1.pointOfView = sceneView1.scene?.rootNode.childNode(withName: "cameraTOP2", recursively: true)
    lid1?.position.y = 150
    box1?.position.y = -600
    lid1?.opacity = 0
    box1?.opacity = 0
    upper1?.opacity = 1
    tongue1?.opacity = 1
    overlay1?.opacity = 1
    midsole1?.opacity = 1
    pods1?.opacity = 1
    outsole1?.opacity = 1
    traction1?.opacity = 1
    SCNTransaction.commit()
}

//
func reboxShoe1() {
    SCNTransaction.begin()
    SCNTransaction.animationDuration = anim1
    sceneView1.pointOfView = sceneView1.scene?.rootNode.childNode(withName: "cameraTOP", recursively: true)
    lid1?.opacity = 0
    box1?.opacity = 0
    upper1?.position.y = 25
    tongue1?.position.y = 30
    overlay1?.position.y = 25
    midsole1?.position.y = 0
    pods1?.position.y = 0
    outsole1?.position.y = 0
    traction1?.position.y = 0
    SCNTransaction.commit()
}

func upperCamera() {
    SCNTransaction.begin()
    SCNTransaction.animationDuration = anim1
    sceneView1.pointOfView = sceneView1.scene?.rootNode.childNode(withName: "cameraUpper", recursively: true)
    lid1?.position.y = 150
    box1?.position.y = -600
    lid1?.opacity = 0
    box1?.opacity = 0
    upper1?.opacity = 1
    tongue1?.opacity = 1
    overlay1?.opacity = 1
    midsole1?.opacity = 1
    pods1?.opacity = 1
    outsole1?.opacity = 1
    traction1?.opacity = 1
    SCNTransaction.commit()
}

func lowerCamera() {
    SCNTransaction.begin()
    SCNTransaction.animationDuration = anim1
    sceneView1.pointOfView = sceneView1.scene?.rootNode.childNode(withName: "cameraLower", recursively: true)
    lid1?.position.y = 150
    box1?.position.y = -600
    lid1?.opacity = 0
    box1?.opacity = 0
    upper1?.opacity = 1
    tongue1?.opacity = 1
    overlay1?.opacity = 1
    midsole1?.opacity = 1
    pods1?.opacity = 1
    outsole1?.opacity = 1
    traction1?.opacity = 1
    SCNTransaction.commit()
}

func midCamera() {
    SCNTransaction.begin()
    SCNTransaction.animationDuration = anim1
    sceneView1.pointOfView = sceneView1.scene?.rootNode.childNode(withName: "cameraMid", recursively: true)
    lid1?.position.y = 150
    box1?.position.y = -600
    lid1?.opacity = 0
    box1?.opacity = 0
    upper1?.opacity = 1
    tongue1?.opacity = 1
    overlay1?.opacity = 1
    midsole1?.opacity = 1
    pods1?.opacity = 1
    outsole1?.opacity = 1
    traction1?.opacity = 1
    SCNTransaction.commit()
}

//
func resetShoe1() {
    SCNTransaction.begin()
    sceneView1.pointOfView = sceneView1.scene?.rootNode.childNode(withName: "cameraTOP", recursively: true)
    lid1?.position.y = 50
    box1?.position.y = 0
    
    lid1?.opacity = 1
    box1?.opacity = 1
    upper1?.opacity = 0
    tongue1?.opacity = 0
    overlay1?.opacity = 0
    midsole1?.opacity = 0
    pods1?.opacity = 0
    outsole1?.opacity = 0
    traction1?.opacity = 0
    
    upper1?.geometry?.firstMaterial?.diffuse.contents = Color.white
    tongue1?.geometry?.firstMaterial?.diffuse.contents = Color.white
    overlay1?.geometry?.firstMaterial?.diffuse.contents = Color.white
    midsole1?.geometry?.firstMaterial?.diffuse.contents = Color.white
    pods1?.geometry?.firstMaterial?.diffuse.contents = Color.white
    outsole1?.geometry?.firstMaterial?.diffuse.contents = Color.white
    traction1?.geometry?.firstMaterial?.diffuse.contents = Color.white
    SCNTransaction.commit()
}

func finishColoring() {
    SCNTransaction.begin()
    SCNTransaction.animationDuration = anim1
    let rotationAction = SCNAction.repeatForever(SCNAction.rotateBy(x: 0, y: 1, z: 0, duration: 1.5))
    rotationAction.timingMode = .easeInEaseOut
    scene1?.rootNode.runAction(rotationAction)
    SCNTransaction.commit()
}

func focus1up() {
    SCNTransaction.begin()
    SCNTransaction.animationDuration = anim1
    sceneView1.pointOfView = sceneView1.scene?.rootNode.childNode(withName: "cameraUpper", recursively: true)
    upper1?.opacity = 1
    tongue1?.opacity = 1
    overlay1?.opacity = 1
    midsole1?.opacity = 0.1
    pods1?.opacity = 0.1
    outsole1?.opacity = 0.1
    traction1?.opacity = 0.1
    SCNTransaction.commit()
}

func focus1mid() {
    SCNTransaction.begin()
    SCNTransaction.animationDuration = anim1
    sceneView1.pointOfView = sceneView1.scene?.rootNode.childNode(withName: "cameraMid2", recursively: true)
    upper1?.opacity = 0.1
    tongue1?.opacity = 0.1
    overlay1?.opacity = 0.1
    midsole1?.opacity = 1
    pods1?.opacity = 1
    outsole1?.opacity = 0.1
    traction1?.opacity = 0.1
    SCNTransaction.commit()
}

func focus1low() {
    SCNTransaction.begin()
    SCNTransaction.animationDuration = anim1
    sceneView1.pointOfView = sceneView1.scene?.rootNode.childNode(withName: "cameraLower", recursively: true)
    upper1?.opacity = 0.1
    tongue1?.opacity = 0.1
    overlay1?.opacity = 0.1
    midsole1?.opacity = 0.1
    pods1?.opacity = 0.1
    outsole1?.opacity = 1
    traction1?.opacity = 1
    SCNTransaction.commit()
}

struct ResView2: PreviewProvider {
    static var previews: some View {
        ResultView()
            .previewInterfaceOrientation(.landscapeLeft)
    }
}
