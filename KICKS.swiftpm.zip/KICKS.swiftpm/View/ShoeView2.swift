import SwiftUI
import SceneKit

let scene2 = type(of: SCNScene()).init(named: "SB2.scn")
let sceneView2 = SCNView()
let anim2 : Double = 2
let anim1 : Double = 1

let upper2 = sceneView2.scene?.rootNode.childNode(withName: "upper", recursively: true)
let midsole2 = sceneView2.scene?.rootNode.childNode(withName: "midsole", recursively: true)
let outsole2 = sceneView2.scene?.rootNode.childNode(withName: "outsole", recursively: true)
let tongue2 = sceneView2.scene?.rootNode.childNode(withName: "tongue", recursively: true)
let overlay2 = sceneView2.scene?.rootNode.childNode(withName: "overlay", recursively: true)
let traction2 = sceneView2.scene?.rootNode.childNode(withName: "traction", recursively: true)
let pods2 = sceneView2.scene?.rootNode.childNode(withName: "pods", recursively: true)
let lid2 = sceneView2.scene?.rootNode.childNode(withName: "lid", recursively: true)
let box2 = sceneView2.scene?.rootNode.childNode(withName: "box", recursively: true)

struct ShoeView2: UIViewRepresentable {
    @State private var selectedNode: SCNNode?
    @State private var originalMaterial: SCNMaterial?

    func makeUIView(context: Context) -> SCNView {
        sceneView2.allowsCameraControl = true
        sceneView2.scene = scene2
        sceneView2.pointOfView = sceneView2.scene?.rootNode.childNode(withName: "cameraTOP", recursively: true)
        sceneView2.autoenablesDefaultLighting = true
        sceneView2.cameraControlConfiguration.panSensitivity = 0.3
        sceneView2.cameraControlConfiguration.truckSensitivity = 0.3
        sceneView2.cameraControlConfiguration.rotationSensitivity = 0.3
        sceneView2.cameraControlConfiguration.flyModeVelocity = 0.1
        
        upper2?.geometry?.firstMaterial?.diffuse.contents = Color.white
        tongue2?.geometry?.firstMaterial?.diffuse.contents = Color.white
        overlay2?.geometry?.firstMaterial?.diffuse.contents = Color.white
        midsole2?.geometry?.firstMaterial?.diffuse.contents = Color.white
        pods2?.geometry?.firstMaterial?.diffuse.contents = Color.white
        outsole2?.geometry?.firstMaterial?.diffuse.contents = Color.white
        traction2?.geometry?.firstMaterial?.diffuse.contents = Color.white


        return sceneView2
    }

    func updateUIView(_ uiView: SCNView, context: Context) {

    }
}

//
func expand2() {
    SCNTransaction.begin()
    SCNTransaction.animationDuration = anim1
    sceneView2.pointOfView = sceneView2.scene?.rootNode.childNode(withName: "cameraTOP3", recursively: true)
    upper2?.position.y = 50
    tongue2?.position.y = 50
    overlay2?.position.y = 50
    midsole2?.position.y = 0
    pods2?.position.y = -25
    outsole2?.position.y = -25
    traction2?.position.y = -25
    SCNTransaction.commit()
}

//
func revealShoe2() {
    SCNTransaction.begin()
    SCNTransaction.animationDuration = anim2
    sceneView2.pointOfView = sceneView2.scene?.rootNode.childNode(withName: "cameraTOP2", recursively: true)
    lid2?.position.y = 150
    box2?.position.y = -600
    lid2?.opacity = 0
    box2?.opacity = 0
    upper2?.opacity = 1
    tongue2?.opacity = 1
    overlay2?.opacity = 1
    midsole2?.opacity = 1
    pods2?.opacity = 1
    outsole2?.opacity = 1
    traction2?.opacity = 1
    SCNTransaction.commit()
}

//
func reboxShoe2() {
    SCNTransaction.begin()
    SCNTransaction.animationDuration = anim1
    sceneView2.pointOfView = sceneView2.scene?.rootNode.childNode(withName: "cameraTOP", recursively: true)
    lid1?.opacity = 0
    box1?.opacity = 0
    upper1?.position.y = 25
    tongue1?.position.y = 30
    overlay1?.position.y = 25
    midsole1?.position.y = 0
    pods1?.position.y = 0
    outsole1?.position.y = 0
    traction1?.position.y = 0
    SCNTransaction.commit()
}

func upperCamera2() {
    SCNTransaction.begin()
    SCNTransaction.animationDuration = anim1
    sceneView2.pointOfView = sceneView2.scene?.rootNode.childNode(withName: "cameraUpper", recursively: true)
    lid2?.position.y = 150
    box2?.position.y = -600
    lid2?.opacity = 0
    box2?.opacity = 0
    upper2?.opacity = 1
    tongue2?.opacity = 1
    overlay2?.opacity = 1
    midsole2?.opacity = 1
    pods2?.opacity = 1
    outsole2?.opacity = 1
    traction2?.opacity = 1
    SCNTransaction.commit()
}

func lowerCamera2() {
    SCNTransaction.begin()
    SCNTransaction.animationDuration = anim1
    sceneView2.pointOfView = sceneView2.scene?.rootNode.childNode(withName: "cameraLower", recursively: true)
    lid2?.position.y = 150
    box2?.position.y = -600
    lid2?.opacity = 0
    box2?.opacity = 0
    upper2?.opacity = 1
    tongue2?.opacity = 1
    overlay2?.opacity = 1
    midsole2?.opacity = 1
    pods2?.opacity = 1
    outsole2?.opacity = 1
    traction2?.opacity = 1
    SCNTransaction.commit()
}

func midCamera2() {
    SCNTransaction.begin()
    SCNTransaction.animationDuration = anim1
    sceneView2.pointOfView = sceneView2.scene?.rootNode.childNode(withName: "cameraMid", recursively: true)
    lid2?.position.y = 150
    box2?.position.y = -600
    lid2?.opacity = 0
    box2?.opacity = 0
    upper2?.opacity = 1
    tongue2?.opacity = 1
    overlay2?.opacity = 1
    midsole2?.opacity = 1
    pods2?.opacity = 1
    outsole2?.opacity = 1
    traction2?.opacity = 1
    SCNTransaction.commit()
}

//
func resetShoe2() {
    SCNTransaction.begin()
    sceneView2.pointOfView = sceneView2.scene?.rootNode.childNode(withName: "cameraTOP", recursively: true)
    lid2?.position.y = 50
    box2?.position.y = 0
    
    lid2?.opacity = 1
    box2?.opacity = 1
    upper2?.opacity = 0
    tongue2?.opacity = 0
    overlay2?.opacity = 0
    midsole2?.opacity = 0
    pods2?.opacity = 0
    outsole2?.opacity = 0
    traction2?.opacity = 0
    
    upper2?.geometry?.firstMaterial?.diffuse.contents = Color.white
    tongue2?.geometry?.firstMaterial?.diffuse.contents = Color.white
    overlay2?.geometry?.firstMaterial?.diffuse.contents = Color.white
    midsole2?.geometry?.firstMaterial?.diffuse.contents = Color.white
    pods2?.geometry?.firstMaterial?.diffuse.contents = Color.white
    outsole2?.geometry?.firstMaterial?.diffuse.contents = Color.white
    traction2?.geometry?.firstMaterial?.diffuse.contents = Color.white
    SCNTransaction.commit()
}

func finishColoring2() {
    SCNTransaction.begin()
    SCNTransaction.animationDuration = anim1
    let rotationAction = SCNAction.repeatForever(SCNAction.rotateBy(x: 0, y: 1, z: 0, duration: 1.5))
    rotationAction.timingMode = .easeInEaseOut
    scene1?.rootNode.runAction(rotationAction)
    SCNTransaction.commit()
}

func focus2up() {
    SCNTransaction.begin()
    SCNTransaction.animationDuration = anim1
    sceneView2.pointOfView = sceneView2.scene?.rootNode.childNode(withName: "cameraUpper", recursively: true)
    upper2?.opacity = 1
    tongue2?.opacity = 1
    overlay2?.opacity = 1
    midsole2?.opacity = 0.1
    pods2?.opacity = 0.1
    outsole2?.opacity = 0.1
    traction2?.opacity = 0.1
    SCNTransaction.commit()
}

func focus2mid() {
    SCNTransaction.begin()
    SCNTransaction.animationDuration = anim1
    sceneView2.pointOfView = sceneView2.scene?.rootNode.childNode(withName: "cameraMid2", recursively: true)
    upper2?.opacity = 0.1
    tongue2?.opacity = 0.1
    overlay2?.opacity = 0.1
    midsole2?.opacity = 1
    pods2?.opacity = 1
    outsole2?.opacity = 0.1
    traction2?.opacity = 0.1
    SCNTransaction.commit()
}

func focus2low() {
    SCNTransaction.begin()
    SCNTransaction.animationDuration = anim1
    sceneView2.pointOfView = sceneView2.scene?.rootNode.childNode(withName: "cameraLower", recursively: true)
    upper2?.opacity = 0.1
    tongue2?.opacity = 0.1
    overlay2?.opacity = 0.1
    midsole2?.opacity = 0.1
    pods2?.opacity = 0.1
    outsole2?.opacity = 1
    traction2?.opacity = 1
    SCNTransaction.commit()
}

struct ResView22: PreviewProvider {
    static var previews: some View {
        ResultView()
            .previewInterfaceOrientation(.landscapeLeft)
    }
}
