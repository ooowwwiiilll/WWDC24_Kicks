import SwiftUI
import SceneKit

let scene3 = type(of: SCNScene()).init(named: "SB3.scn")
let sceneView3 = SCNView()

let upper3 = sceneView3.scene?.rootNode.childNode(withName: "upper", recursively: true)
let midsole3 = sceneView3.scene?.rootNode.childNode(withName: "midsole", recursively: true)
let outsole3 = sceneView3.scene?.rootNode.childNode(withName: "outsole", recursively: true)
let tongue3 = sceneView3.scene?.rootNode.childNode(withName: "tongue", recursively: true)
let overlay3 = sceneView3.scene?.rootNode.childNode(withName: "overlay", recursively: true)
let traction3 = sceneView3.scene?.rootNode.childNode(withName: "traction", recursively: true)
let pods3 = sceneView3.scene?.rootNode.childNode(withName: "pods", recursively: true)
let lid3 = sceneView3.scene?.rootNode.childNode(withName: "lid", recursively: true)
let box3 = sceneView3.scene?.rootNode.childNode(withName: "box", recursively: true)

struct ShoeView3: UIViewRepresentable {
    @State private var selectedNode: SCNNode?
    @State private var originalMaterial: SCNMaterial?

    func makeUIView(context: Context) -> SCNView {
        sceneView3.allowsCameraControl = true
        sceneView3.scene = scene3
        sceneView3.pointOfView = sceneView3.scene?.rootNode.childNode(withName: "cameraTOP", recursively: true)
        sceneView3.autoenablesDefaultLighting = true
        sceneView3.cameraControlConfiguration.panSensitivity = 0.3
        sceneView3.cameraControlConfiguration.truckSensitivity = 0.3
        sceneView3.cameraControlConfiguration.rotationSensitivity = 0.3
        sceneView3.cameraControlConfiguration.flyModeVelocity = 0.1
        
        upper3?.geometry?.firstMaterial?.diffuse.contents = Color.white
        tongue3?.geometry?.firstMaterial?.diffuse.contents = Color.white
        overlay3?.geometry?.firstMaterial?.diffuse.contents = Color.white
        midsole3?.geometry?.firstMaterial?.diffuse.contents = Color.white
        pods3?.geometry?.firstMaterial?.diffuse.contents = Color.white
        outsole3?.geometry?.firstMaterial?.diffuse.contents = Color.white
        traction3?.geometry?.firstMaterial?.diffuse.contents = Color.white

        return sceneView3
    }

    func updateUIView(_ uiView: SCNView, context: Context) {

    }
}

func expand3() {
    SCNTransaction.begin()
    SCNTransaction.animationDuration = anim2
    sceneView3.pointOfView = sceneView1.scene?.rootNode.childNode(withName: "cameraTOP3", recursively: true)
    upper3?.position.y = 25
    tongue3?.position.y = 50
    overlay3?.position.y = 50
    midsole3?.position.y = 0
    pods3?.position.y = 0
    outsole3?.position.y = -25
    traction3?.position.y = -25
    SCNTransaction.commit()
}

func revealShoe3() {
    SCNTransaction.begin()
    SCNTransaction.animationDuration = anim2
    sceneView3.pointOfView = sceneView3.scene?.rootNode.childNode(withName: "cameraTOP2", recursively: true)
    lid3?.position.y = 150
    box3?.position.y = -600
    lid3?.opacity = 0
    box3?.opacity = 0
    upper3?.opacity = 1
    tongue3?.opacity = 1
    overlay3?.opacity = 1
    midsole3?.opacity = 1
    pods3?.opacity = 1
    outsole3?.opacity = 1
    traction3?.opacity = 1
    SCNTransaction.commit()
}

func reboxShoe3() {
    SCNTransaction.begin()
    SCNTransaction.animationDuration = anim2
    sceneView3.pointOfView = sceneView3.scene?.rootNode.childNode(withName: "cameraTOP", recursively: true)
    lid3?.position.x = .init()
    box3?.position.y = .init()
    upper3?.position.y = 25
    tongue3?.position.y = 30
    overlay3?.position.y = 25
    midsole3?.position.y = 0
    pods3?.position.y = 0
    outsole3?.position.y = 0
    traction3?.position.y = 0
    SCNTransaction.commit()
}

func upperCamera3() {
    SCNTransaction.begin()
    SCNTransaction.animationDuration = anim1
    sceneView3.pointOfView = sceneView3.scene?.rootNode.childNode(withName: "cameraUpper", recursively: true)
    lid3?.position.y = 150
    box3?.position.y = -600
    lid3?.opacity = 0
    box3?.opacity = 0
    upper3?.opacity = 1
    tongue3?.opacity = 1
    overlay3?.opacity = 1
    midsole3?.opacity = 1
    pods3?.opacity = 1
    outsole3?.opacity = 1
    traction3?.opacity = 1
    SCNTransaction.commit()
}

func lowerCamera3() {
    SCNTransaction.begin()
    SCNTransaction.animationDuration = anim1
    sceneView3.pointOfView = sceneView3.scene?.rootNode.childNode(withName: "cameraLower", recursively: true)
    lid3?.position.y = 150
    box3?.position.y = -600
    lid3?.opacity = 0
    box3?.opacity = 0
    upper3?.opacity = 1
    tongue3?.opacity = 1
    overlay3?.opacity = 1
    midsole3?.opacity = 1
    pods3?.opacity = 1
    outsole3?.opacity = 1
    traction3?.opacity = 1
    SCNTransaction.commit()
}

func midCamera3() {
    SCNTransaction.begin()
    SCNTransaction.animationDuration = anim1
    sceneView3.pointOfView = sceneView3.scene?.rootNode.childNode(withName: "cameraMid", recursively: true)
    lid3?.position.y = 150
    box3?.position.y = -600
    lid3?.opacity = 0
    box3?.opacity = 0
    upper3?.opacity = 1
    tongue3?.opacity = 1
    overlay3?.opacity = 1
    midsole3?.opacity = 1
    pods3?.opacity = 1
    outsole3?.opacity = 1
    traction3?.opacity = 1
    SCNTransaction.commit()
}

func resetShoe3() {
    SCNTransaction.begin()
    sceneView3.pointOfView = sceneView3.scene?.rootNode.childNode(withName: "cameraTOP", recursively: true)
    lid3?.position.y = 50
    box3?.position.y = 0
    
    lid3?.opacity = 1
    box3?.opacity = 1
    upper3?.opacity = 0
    tongue3?.opacity = 0
    overlay3?.opacity = 0
    midsole3?.opacity = 0
    pods3?.opacity = 0
    outsole3?.opacity = 0
    traction3?.opacity = 0
    
    upper3?.geometry?.firstMaterial?.diffuse.contents = Color.white
    tongue3?.geometry?.firstMaterial?.diffuse.contents = Color.white
    overlay3?.geometry?.firstMaterial?.diffuse.contents = Color.white
    midsole3?.geometry?.firstMaterial?.diffuse.contents = Color.white
    pods3?.geometry?.firstMaterial?.diffuse.contents = Color.white
    outsole3?.geometry?.firstMaterial?.diffuse.contents = Color.white
    traction3?.geometry?.firstMaterial?.diffuse.contents = Color.white
    SCNTransaction.commit()
}

func finishColoring3() {
    SCNTransaction.begin()
    SCNTransaction.animationDuration = anim1
    let rotationAction = SCNAction.repeatForever(SCNAction.rotateBy(x: 0, y: 1, z: 0, duration: 1.5))
    rotationAction.timingMode = .easeInEaseOut
    scene1?.rootNode.runAction(rotationAction)
    SCNTransaction.commit()
}

func focus3up() {
    SCNTransaction.begin()
    SCNTransaction.animationDuration = anim1
    sceneView3.pointOfView = sceneView3.scene?.rootNode.childNode(withName: "cameraUpper", recursively: true)
    upper3?.opacity = 1
    tongue3?.opacity = 1
    overlay3?.opacity = 1
    midsole3?.opacity = 0.1
    pods3?.opacity = 0.1
    outsole3?.opacity = 0.1
    traction3?.opacity = 0.1
    SCNTransaction.commit()
}

func focus3mid() {
    SCNTransaction.begin()
    SCNTransaction.animationDuration = anim1
    sceneView3.pointOfView = sceneView3.scene?.rootNode.childNode(withName: "cameraMid", recursively: true)
    upper3?.opacity = 0.1
    tongue3?.opacity = 0.1
    overlay3?.opacity = 0.1
    midsole3?.opacity = 1
    pods3?.opacity = 1
    outsole3?.opacity = 0.1
    traction3?.opacity = 0.1
    SCNTransaction.commit()
}

func focus3low() {
    SCNTransaction.begin()
    SCNTransaction.animationDuration = anim1
    sceneView3.pointOfView = sceneView3.scene?.rootNode.childNode(withName: "cameraLower", recursively: true)
    upper3?.opacity = 0.1
    tongue3?.opacity = 0.1
    overlay3?.opacity = 0.1
    midsole3?.opacity = 0.1
    pods3?.opacity = 0.1
    outsole3?.opacity = 1
    traction3?.opacity = 1
    SCNTransaction.commit()
}

struct ResView3: PreviewProvider {
    static var previews: some View {
        ResultView()
            .previewInterfaceOrientation(.landscapeLeft)
    }
}
