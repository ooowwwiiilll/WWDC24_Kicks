import SwiftUI
import SceneKit

struct Story: Identifiable {
    var id = UUID()
    var text: String
}

let storyList = [
    Story(text: "for many people, shoes are often overlooked. seen merely as a functional necessity."),
    Story(text: "but for basketball enthusiasts ((like me)), it is a HOLY GRAIL & an Art Piece. i love to call them KICKS."),
    Story(text: "KICKS plays a crucial part in basketball. \nprotecting and comforting every steps."),
    Story(text: "a typical KICKS consists of these 3 main parts. \neach parts have their own responsibility."),
    Story(text: "especially for an athlete, our KICKS are key to our performance. picking the wrong KICKS will reduce your comfort."),
    Story(text: "and just like that quote said... 'Feel Good, Play Good'."),
    Story(text: "i personally had an experience wearing KICKS that did not suit my playstyle and injure myself"),
    Story(text: "let's prevent it from happening to you. \nlet’s craft an exclusive KICKS that suits you!")
]

struct StoryView: View {
    @State var currentStory = 0
    
    let thick: CGFloat = 5
    var story = storyList
    @State var storySpec = false
    @State var showStory = 0.0
    @State var showNext = 0.0
    @State var emoji1 = 0.0
    @State var emoji2 = 0.0
    @State var emoji3 = 0.0
    @State var returnPos = 0
    
    var body: some View {
        NavigationStack {
            ZStack {
                VStack(spacing: 30) {
                    
                    HStack {
                        Text("STORY")
                        Spacer()
                        Text("01")
                    }
                    .bigTitle()
                    .foregroundColor(Color("IVORY"))
                    
                    Rectangle()
                        .fill(Color("IVORY"))
                        .frame(height: thick)
                    
                    ZStack() {
                        VStack {
                            HStack {
                                Text(story[currentStory].text)
                                
                                Spacer()
                            }
                                .foregroundStyle(Color("IVORY"))
                                .multilineTextAlignment(.leading)
                                .title1()
                            
                            Spacer()
                        }
                        
                        ZStack {
                            ZStack {
                                Image("ShoeSample")
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .blendMode(.lighten)
                                    .opacity(currentStory >= 4 ? 0.2 : 1)
                                
                                Image("ShoeSample2")
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .blendMode(.lighten)
                                    .opacity(currentStory >= 1 ? 1 : 0)
                                    .opacity(currentStory >= 4 ? 0.2 : 1)
                                
                                Image("Details")
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .opacity(currentStory == 4 ? 1 : 0)
                                
                                if currentStory == 1 {
                                    Image("ShoeE1")
                                        .resizable()
                                        .aspectRatio(contentMode: .fit)
                                        .opacity(emoji1)
                                        .onAppear() {
                                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.6) {
                                                emoji1 = 1
                                            }
                                        }
                                    
                                    Image("ShoeE2")
                                        .resizable()
                                        .aspectRatio(contentMode: .fit)
                                        .opacity(emoji2)
                                        .onAppear() {
                                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.9) {
                                                emoji2 = 1
                                            }
                                        }
                                    
                                    Image("ShoeE3")
                                        .resizable()
                                        .aspectRatio(contentMode: .fit)
                                        .opacity(emoji3)
                                        .onAppear() {
                                            DispatchQueue.main.asyncAfter(deadline: .now() + 1.2) {
                                                emoji3 = 1
                                            }
                                        }
                                    
                                }
                            }
                            .scaleEffect(currentStory == 1 ? 1.3 : 1.0)
                            .scaleEffect(currentStory == 3 ? 1.1 : 1.0)
                            .scaleEffect(currentStory == 7 ? 1.5 : 1.0)
                            
                            ZStack {
                                Image("specIn")
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .opacity(currentStory == 5 ? 1 : 0)
                                    .shadow(color: .white, radius: 15)

                                Image("specTrac")
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .offset(x: currentStory == 3 ? 30: 0, y: currentStory == 3 ? 160 : 0)
                                    .scaleEffect(currentStory == 3 ? 0.3 : 1)
                                    .opacity(currentStory == 6 ? 0 : 1)
                                
                                Image("specCushion")
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .offset(x: currentStory == 3 ? -240 : 0, y: currentStory == 3 ? 90 : 0)
                                    .scaleEffect(currentStory == 3 ? 0.3 : 1)
                                
                                Image("specUpper")
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .offset(y: currentStory == 3 ? -90 : 0)
                                    .scaleEffect(currentStory == 3 ? 0.3 : 1)
                            }
                            .frame(width: UIScreen.main.bounds.height / 2)
                            .opacity(currentStory >= 3 ? 1 : 0)
                            .opacity(currentStory == 7 ? 0 : 1)
                        }
                        .padding(.top, 120)
                    }
                    .opacity(showStory)
                    .onAppear() {
                        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
                            withAnimation(.spring) {
                                showStory = 1
                            }
                        }
                    }
                    
                    ZStack(alignment: .top) {
                        Rectangle()
                            .fill(Color("IVORY"))
                            .frame(height: thick)
                        
                        HStack(alignment: .bottom, spacing: 30) {
                            Button {
                                withAnimation(.spring(duration: 1)) {
                                    currentStory -= 1
                                }
                            } label: {
                                Text("BACK")
                                .title1()
                                .foregroundStyle(Color("IVORY"))
                                .padding(.horizontal, 30)
                                .padding(.vertical, 15)
                                .background(Color("BLUE"))
                                .cornerRadius(100)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 100)
                                        .inset(by: 2)
                                        .stroke(Color("IVORY"), lineWidth: thick)
                                )
                            }
                            .opacity(currentStory >= 1 ? 1 : 0)
                            .opacity(showNext)
                            .onAppear() {
                                DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
                                    withAnimation(.spring) {
                                        showNext = 1
                                    }
                                }
                            }
                            
                            Spacer()
                            
                            Rectangle()
                                .fill(Color("IVORY"))
                                .frame(width:thick, height: 104)
                                .opacity(0)
                            
                            if (storyList.count - currentStory != 1) {
                                Button {
                                    withAnimation(.spring(duration: 1)) {
                                        currentStory += 1
                                    }
                                } label: {
                                    Text("NEXT")
                                    .title1()
                                    .foregroundStyle(Color("IVORY"))
                                    .padding(.horizontal, 30)
                                    .padding(.vertical, 15)
                                    .background(Color("BLUE"))
                                    .cornerRadius(100)
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 100)
                                            .inset(by: 2)
                                            .stroke(Color("IVORY"), lineWidth: thick)
                                    )
                                }
                                .opacity(showNext)
                                .onAppear() {
                                    DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
                                        withAnimation(.spring) {
                                            showNext = 1
                                        }
                                    }
                                }
                            }
                            
                            if storyList.count - currentStory == 1 {
                                withAnimation(.spring) {
                                    NavigationLink {
                                        QuizView()
                                    } label: {
                                        HStack {
                                            Text("GO TO LAB")
                                                .title1()
                                            Image(systemName: "arrow.right")
                                                .font(.largeTitle)
                                        }
                                        .foregroundStyle(Color("BLUE"))
                                        .padding(.horizontal, 30)
                                        .padding(.vertical, 15)
                                        .background(Color("IVORY"))
                                        .cornerRadius(100)
                                    }
                                }
                            }
                            
                        }
                    }
                }
                .padding(.horizontal, 60)
                .padding(.vertical, 30)

            }
            .navigationTitle("")
            .background(Color("BLUE"))
        }
    }
}

struct StoryPreview: PreviewProvider {
    static var previews: some View {
        StoryView()
            .previewInterfaceOrientation(.landscapeLeft)
    }
}


